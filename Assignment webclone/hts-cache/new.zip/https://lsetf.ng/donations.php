<!DOCTYPE html>
<html lang="en" dir="ltr" prefix="content: http://purl.org/rss/1.0/modules/content/ dc: http://purl.org/dc/terms/ foaf: http://xmlns.com/foaf/0.1/ og: http://ogp.me/ns# rdfs: http://www.w3.org/2000/01/rdf-schema# sioc: http://rdfs.org/sioc/ns# sioct: http://rdfs.org/sioc/types# skos: http://www.w3.org/2004/02/skos/core# xsd: http://www.w3.org/2001/XMLSchema#">
<head>
    
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-X4ZYCT6PZM"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-X4ZYCT6PZM');
</script>

  <link rel="profile" href="http://www.w3.org/1999/xhtml/vocab" />
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Generator" content="Drupal 7 (http://drupal.org); Commerce 1" />
<!-- VISA Tracking Code for https://lsetf.ng --><script>(function(v,i,s,a,t){v[t]=v[t]||function(){(v[t].v=v[t].v||[]).push(arguments)};if(!v._visaSettings){v._visaSettings={}}v._visaSettings[a]={v:'1.0',s:a,a:'1',t:t};var b=i.getElementsByTagName('head')[0];var p=i.createElement('script');p.defer=1;p.async=1;p.src=s+'?s='+a;b.appendChild(p)})(window,document,'//app-worker.visitor-analytics.io/main.js','8b11bf95-59c8-11ec-b589-901b0edac50a','va')</script><!-- VISA Tracking Code for https://lsetf.ng -->  <title>Page not found | LSETF | Lagos State Employment Trust Fund</title>
  <style>
@import url("https://lsetf.ng/modules/system/system.base.css?rz0jao");
</style>
<style>
@import url("https://lsetf.ng/sites/all/modules/calendar/css/calendar_multiday.css?rz0jao");
@import url("https://lsetf.ng/modules/field/theme/field.css?rz0jao");
@import url("https://lsetf.ng/modules/node/node.css?rz0jao");
@import url("https://lsetf.ng/sites/all/modules/ubercart/uc_order/uc_order.css?rz0jao");
@import url("https://lsetf.ng/sites/all/modules/ubercart/uc_product/uc_product.css?rz0jao");
@import url("https://lsetf.ng/sites/all/modules/ubercart/uc_store/uc_store.css?rz0jao");
@import url("https://lsetf.ng/sites/all/modules/views/css/views.css?rz0jao");
@import url("https://lsetf.ng/sites/all/modules/ckeditor/css/ckeditor.css?rz0jao");
@import url("https://lsetf.ng/sites/all/modules/media/modules/media_wysiwyg/css/media_wysiwyg.base.css?rz0jao");
</style>
<style>
@import url("https://lsetf.ng/sites/all/modules/colorbox/styles/default/colorbox_style.css?rz0jao");
@import url("https://lsetf.ng/sites/all/modules/ctools/css/ctools.css?rz0jao");
@import url("https://lsetf.ng/sites/all/modules/lightbox2/css/lightbox.css?rz0jao");
</style>
<link type="text/css" rel="stylesheet" href="https://lsetf.ng/sites/all/modules/popup/popup.css?rz0jao" media="all" />
<style>
@import url("https://lsetf.ng/sites/all/modules/addtoany/addtoany.css?rz0jao");
@import url("https://lsetf.ng/sites/all/libraries/fontawesome/css/font-awesome.css?rz0jao");
</style>
<link type="text/css" rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.5/dist/css/bootstrap.css" media="all" />
<link type="text/css" rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@unicorn-fail/drupal-bootstrap-styles@0.0.2/dist/3.3.1/7.x-3.x/drupal-bootstrap.css" media="all" />
<style>
@import url("https://lsetf.ng/sites/all/themes/ysl/css/style.css?rz0jao");
</style>
  <link href="https://lsetf.ng/sites/all/themes/ysl/css/ihover.css" rel="stylesheet">
  <link href="https://lsetf.ng/sites/all/themes/ysl/css/animate.css" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="//fast.fonts.net/cssapi/c774e746-6bf6-454a-b9d4-ff448a288b90.css"/>
  <!-- UNCOMMENT INSERT CUSTOM FONTS HERE  
      <link type="text/css" rel="stylesheet" href="//fast.fonts.net/cssapi/b6dbe323-4249-4073-a513-4c4b6839dde1.css"/>
  -->
  <!-- HTML5 element support for IE6-8 -->
  <!--[if lt IE 9]>
    <script src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv-printshiv.min.js"></script>
  <![endif]-->
  <script src="https://lsetf.ng/sites/all/libraries/modernizr/modernizr.min.js?rz0jao"></script>
<script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script>window.jQuery || document.write("<script src='/sites/all/modules/jquery_update/replace/jquery/1.10/jquery.min.js'>\x3C/script>")</script>
<script src="https://lsetf.ng/misc/jquery-extend-3.4.0.js?v=1.10.2"></script>
<script src="https://lsetf.ng/misc/jquery-html-prefilter-3.5.0-backport.js?v=1.10.2"></script>
<script src="https://lsetf.ng/misc/jquery.once.js?v=1.2"></script>
<script src="https://lsetf.ng/misc/drupal.js?rz0jao"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.5/dist/js/bootstrap.js"></script>
<script src="https://lsetf.ng/sites/all/libraries/colorbox/jquery.colorbox-min.js?rz0jao"></script>
<script src="https://lsetf.ng/sites/all/modules/colorbox/js/colorbox.js?rz0jao"></script>
<script src="https://lsetf.ng/sites/all/modules/colorbox/styles/default/colorbox_style.js?rz0jao"></script>
<script src="https://lsetf.ng/sites/all/modules/lightbox2/js/lightbox.js?1695026788"></script>
<script src="https://lsetf.ng/sites/all/modules/popup/popup.js?rz0jao"></script>
<script src="https://lsetf.ng/sites/all/modules/google_analytics/googleanalytics.js?rz0jao"></script>
<script src="https://www.googletagmanager.com/gtag/js?id=UA-104219270-1"></script>
<script>window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments)};gtag("js", new Date());gtag("set", "developer_id.dMDhkMT", true);gtag("config", "UA-104219270-1", {"groups":"default","anonymize_ip":true,"page_path":"/404.html?page=" + document.location.pathname + document.location.search + "&from=" + document.referrer});</script>
<script>jQuery.extend(Drupal.settings, {"basePath":"\/","pathPrefix":"","ajaxPageState":{"theme":"ysl","theme_token":"EOiZVOZ8o9mR_DoK4T9YloTL19g2pTlmTyVrHiKVhDo","js":{"sites\/all\/themes\/bootstrap\/js\/bootstrap.js":1,"sites\/all\/libraries\/modernizr\/modernizr.min.js":1,"\/\/code.jquery.com\/jquery-1.10.2.min.js":1,"0":1,"misc\/jquery-extend-3.4.0.js":1,"misc\/jquery-html-prefilter-3.5.0-backport.js":1,"misc\/jquery.once.js":1,"misc\/drupal.js":1,"https:\/\/cdn.jsdelivr.net\/npm\/bootstrap@3.3.5\/dist\/js\/bootstrap.js":1,"sites\/all\/libraries\/colorbox\/jquery.colorbox-min.js":1,"sites\/all\/modules\/colorbox\/js\/colorbox.js":1,"sites\/all\/modules\/colorbox\/styles\/default\/colorbox_style.js":1,"sites\/all\/modules\/lightbox2\/js\/lightbox.js":1,"sites\/all\/modules\/popup\/popup.js":1,"sites\/all\/modules\/google_analytics\/googleanalytics.js":1,"https:\/\/www.googletagmanager.com\/gtag\/js?id=UA-104219270-1":1,"1":1},"css":{"modules\/system\/system.base.css":1,"sites\/all\/modules\/calendar\/css\/calendar_multiday.css":1,"modules\/field\/theme\/field.css":1,"modules\/node\/node.css":1,"sites\/all\/modules\/ubercart\/uc_order\/uc_order.css":1,"sites\/all\/modules\/ubercart\/uc_product\/uc_product.css":1,"sites\/all\/modules\/ubercart\/uc_store\/uc_store.css":1,"sites\/all\/modules\/views\/css\/views.css":1,"sites\/all\/modules\/ckeditor\/css\/ckeditor.css":1,"sites\/all\/modules\/media\/modules\/media_wysiwyg\/css\/media_wysiwyg.base.css":1,"sites\/all\/modules\/colorbox\/styles\/default\/colorbox_style.css":1,"sites\/all\/modules\/ctools\/css\/ctools.css":1,"sites\/all\/modules\/lightbox2\/css\/lightbox.css":1,"sites\/all\/modules\/popup\/popup.css":1,"sites\/all\/modules\/addtoany\/addtoany.css":1,"sites\/all\/libraries\/fontawesome\/css\/font-awesome.css":1,"https:\/\/cdn.jsdelivr.net\/npm\/bootstrap@3.3.5\/dist\/css\/bootstrap.css":1,"https:\/\/cdn.jsdelivr.net\/npm\/@unicorn-fail\/drupal-bootstrap-styles@0.0.2\/dist\/3.3.1\/7.x-3.x\/drupal-bootstrap.css":1,"sites\/all\/themes\/ysl\/css\/style.css":1}},"colorbox":{"opacity":"0.85","current":"{current} of {total}","previous":"\u00ab Prev","next":"Next \u00bb","close":"Close","maxWidth":"98%","maxHeight":"98%","fixed":true,"mobiledetect":true,"mobiledevicewidth":"480px","file_public_path":"\/sites\/default\/files","specificPagesDefaultValue":"admin*\nimagebrowser*\nimg_assist*\nimce*\nnode\/add\/*\nnode\/*\/edit\nprint\/*\nprintpdf\/*\nsystem\/ajax\nsystem\/ajax\/*"},"lightbox2":{"rtl":0,"file_path":"\/(\\w\\w\/)public:\/","default_image":"\/sites\/all\/modules\/lightbox2\/images\/brokenimage.jpg","border_size":10,"font_color":"000","box_color":"fff","top_position":"","overlay_opacity":"0.8","overlay_color":"000","disable_close_click":true,"resize_sequence":0,"resize_speed":400,"fade_in_speed":400,"slide_down_speed":600,"use_alt_layout":false,"disable_resize":false,"disable_zoom":false,"force_show_nav":false,"show_caption":true,"loop_items":false,"node_link_text":"View Image Details","node_link_target":false,"image_count":"Image !current of !total","video_count":"Video !current of !total","page_count":"Page !current of !total","lite_press_x_close":"press \u003Ca href=\u0022#\u0022 onclick=\u0022hideLightbox(); return FALSE;\u0022\u003E\u003Ckbd\u003Ex\u003C\/kbd\u003E\u003C\/a\u003E to close","download_link_text":"","enable_login":false,"enable_contact":false,"keys_close":"c x 27","keys_previous":"p 37","keys_next":"n 39","keys_zoom":"z","keys_play_pause":"32","display_image_size":"original","image_node_sizes":"()","trigger_lightbox_classes":"","trigger_lightbox_group_classes":"","trigger_slideshow_classes":"","trigger_lightframe_classes":"","trigger_lightframe_group_classes":"","custom_class_handler":0,"custom_trigger_classes":"","disable_for_gallery_lists":true,"disable_for_acidfree_gallery_lists":true,"enable_acidfree_videos":true,"slideshow_interval":5000,"slideshow_automatic_start":true,"slideshow_automatic_exit":true,"show_play_pause":true,"pause_on_next_click":false,"pause_on_previous_click":true,"loop_slides":false,"iframe_width":600,"iframe_height":400,"iframe_border":1,"enable_video":false},"popup":{"effects":{"show":{"default":"this.body.show();","fade":"\n        if (this.opacity){\n          this.body.fadeTo(\u0027medium\u0027,this.opacity);\n        }else{\n          this.body.fadeIn(\u0027medium\u0027);\n        }","slide-down":"this.body.slideDown(\u0027medium\u0027)","slide-down-fade":"\n        this.body.animate(\n          {\n            height:\u0027show\u0027,\n            opacity:(this.opacity ? this.opacity : \u0027show\u0027)\n          }, \u0027medium\u0027\n        );"},"hide":{"default":"this.body.hide();","fade":"this.body.fadeOut(\u0027medium\u0027);","slide-down":"this.body.slideUp(\u0027medium\u0027);","slide-down-fade":"\n        this.body.animate(\n          {\n            height:\u0027hide\u0027,\n            opacity:\u0027hide\u0027\n          }, \u0027medium\u0027\n        );"}},"linger":250,"delay":0},"googleanalytics":{"account":["UA-104219270-1"],"trackOutbound":1,"trackMailto":1,"trackDownload":1,"trackDownloadExtensions":"7z|aac|arc|arj|asf|asx|avi|bin|csv|doc(x|m)?|dot(x|m)?|exe|flv|gif|gz|gzip|hqx|jar|jpe?g|js|mp(2|3|4|e?g)|mov(ie)?|msi|msp|pdf|phps|png|ppt(x|m)?|pot(x|m)?|pps(x|m)?|ppam|sld(x|m)?|thmx|qtm?|ra(m|r)?|sea|sit|tar|tgz|torrent|txt|wav|wma|wmv|wpd|xls(x|m|b)?|xlt(x|m)|xlam|xml|z|zip","trackColorbox":1},"better_exposed_filters":{"views":{"news_ticker":{"displays":{"block":{"filters":[]}}}}},"bootstrap":{"anchorsFix":"0","anchorsSmoothScrolling":"0","formHasError":1,"popoverEnabled":1,"popoverOptions":{"animation":1,"html":0,"placement":"right","selector":"","trigger":"click","triggerAutoclose":1,"title":"","content":"","delay":0,"container":"body"},"tooltipEnabled":1,"tooltipOptions":{"animation":1,"html":0,"placement":"auto left","selector":"","trigger":"hover focus","delay":0,"container":"body"}}});</script>
  <script src="https://lsetf.ng/sites/all/libraries/scrolltext/jQuery.scrollText.js"></script>
  <script type="text/javascript">


    jQuery(document).ready(function() {

      // append check if we have photos on page and append click function to show bios (applies management profile, board of trustees pages)
      zPhoto = jQuery(".photo").length;
    
      // alert(zPhoto);
      if (zPhoto > 0){
        zPhotoDiv = jQuery('.photo');
        zPhotoDiv.click(showBio);
      }

      zBlogDiv = jQuery(".front .view-id-blog .item-list").length;
      jQuery(".field-name-field-author h2 a").removeAttr("href"); 

      if (zBlogDiv > 0){
        // console.log(zBlogDiv);
        /*
        jQuery(".view-id-blog .item-list").scrollText({
          'container': '.item-list', 
          'sections': 'li', 
          'duration': 1000,
          'loop': true,
          'direction': 'up'  
        });
        */
      }


      

    });

    function showBio(){
      // alert('sdfs');
      zBio = this.parentNode.childNodes[7];
      zBioMessage = jQuery('#bio .message')[0];
      zBioMessage.innerHTML = zBio.innerHTML;
      zBlackout = jQuery('#blackout');
      
      // zBlackout.removeClass('fadeIn');
      zBlackout.css('visibility', 'visible');
      // zBlackout.addClass('fadeIn');
      // zBio = jQuery('#bio');
      // zBio.css('visibility', 'visible');
      console.log(zBio.innerHTML);
    }

    function closeBio(){
      zBlackout = jQuery('#blackout');
      zBlackout.css('visibility', 'hidden');
    }
    
    function toggleMenu(option){

      if (option < 1){

        // hide menu
        // fade out cover div
        // slideout menu
        jQuery('#coverDiv').addClass('fadeOut').removeClass('fadeIn showme').addClass('hideme');
        jQuery('#fancyMenu').addClass('slideOutRight').removeClass('slideInRight');

      } else {

        jQuery('#coverDiv').addClass('fadeIn showme').removeClass('fadeOut hideme');
        jQuery('#fancyMenu').addClass('slideInRight showme').removeClass('slideOutRight hideme');

      }
    }


  </script>
  <script type="text/javascript" charset="UTF-8" src="//cdn.cookie-script.com/s/debaf0a8eacf436c4be0a4c755fee150.js"></script>
  <script type="text/javascript" id="zsiqchat">var $zoho=$zoho || {};$zoho.salesiq = $zoho.salesiq || {widgetcode: "1b00edb396e5d27d9bba684c0826e932b22c59239b1582ff754749874579e77d", values:{},ready:function(){}};var d=document;s=d.createElement("script");s.type="text/javascript";s.id="zsiqscript";s.defer=true;s.src="https://salesiq.zoho.com/widget";t=d.getElementsByTagName("script")[0];t.parentNode.insertBefore(s,t);</script>
</head>


<body class="navbar-is-static-top html not-front not-logged-in no-sidebars page-donationsphp">
    <div class="con2">
  <div id="skip-link">
    <a href="#main-content" class="element-invisible element-focusable">Skip to main content</a>
  </div>
    <div class="blackout animated fadeIn" id="blackout" onClick="closeBio()"><div id="bio" class="xanimated xslideInUp xdelay-3"><div class="close"><a href="javascript:closeBio()"><i class="fa fa-close fa-2x"></i></a></div><div class="message"></div></div></div><div class='innercontainer'>  <div class='innerheader bg-5'>&nbsp;</div></div>  <!-- <div class="headlines">
    <div class="container">
      
      <div class="feed">     
              </div>
    </div>
  </div> -->
  <div class="mini-top-bar">
  <div class="box-grid">
    <div class="mini-box mobile-hide">
      <div>
        <i class="fa fa-clock-o" aria-hidden="true"></i>
      </div>
      <div>
        SERVICE HOURS<br />
        Mon - Fri: 8:00am - 5:00pm
      </div>
    </div>
    <div class="mobile-hide">
      <div class="mini-box">
      <div>
        <i class="fa fa-phone" aria-hidden="true"></i>
      </div>
      <div>
        CALL US<br />
        01 700 0945
      </div>
    </div>
    </div>
    <div class="box-social">
      <a href="https://www.facebook.com/LSETF-1710232582574952/" target="_blank"><i class="fa fa-facebook">&nbsp;</i></a>
      <a href="https://twitter.com/lsetf/" target="_blank"><i class="fa fa-twitter">&nbsp;</i></a>
      <a href="https://www.instagram.com/lsetf/" target="_blank"><i class="fa fa-instagram">&nbsp;</i></a>
      <a href="https://www.youtube.com/channel/UC272pnSAyeP2NNZPwvWtziw" target="_blank"><i class="fa fa-youtube">&nbsp;</i></a>
    </div>
    <div class="box-apply">
      <!--<a href="https://lsetf.ng/content/msme-loan-programme" target="_blank" class="btn btn-primary">Apply</a>-->
    </div>
  </div>
  <!-- <a href="/downloads" class="textlink">Downloads</a>
  <a href="/blog" class="textlink">Blog</a>
  <a href="https://twitter.com/lsetf/" target="_blank"><i class="fa fa-twitter">&nbsp;</i></a>
  <a href="https://www.facebook.com/LSETF-1710232582574952/" target="_blank"><i class="fa fa-facebook">&nbsp;</i></a>
  <a href="https://www.instagram.com/lsetf/" target="_blank"><i class="fa fa-instagram">&nbsp;</i></a>
  <a href="https://www.youtube.com/channel/UC272pnSAyeP2NNZPwvWtziw" target="_blank"><i class="fa fa-youtube">&nbsp;</i></a> -->
</div>
<header id="navbar" role="banner" class="navbar navbar-static-top navbar-default">
  <div xclass="container">
    <!--  -->
    <div class="navbar-header">
              <div class="logo">
          <a class="navbar-btn" href="/" title="Home">
            <img src="https://lsetf.ng/sites/default/files/logo_0.png" alt="Home" />
          </a>
        </div>
      
        </div>
</header>

<div class="main-container container">

  <header role="banner" id="page-header">
    
      </header> <!-- /#page-header -->

  <div class="row zero-top">

    
            <section class="col-sm-12">
                <!--  -->
      <a id="main-content"></a>
                    <h1 class="page-header animated fadeIn ">Page not found</h1>
                 
                                              <div class="region region-content">
    <section id="block-system-main" class="block block-system clearfix">

      
  The requested page "/donations.php" could not be found.
</section>
  </div>
    </section>

    
  </div>
</div>
  <div class="whistleblower">
    <div class="container">
      <a href="http://www.lagosinnovates.ng" target="_blank"><img src="/sites/all/themes/ysl/img/li-logo.jpg" height="60" /></a>&nbsp;&nbsp;
      <a href="http://www.lsesp.ng" target="_blank"><img src="/sites/all/themes/ysl/img/lsesp-logo.jpg" height="60" /></a>
      <h3>To read our whistle blowing policy</h3> 
      <a href="/content/whistle-blowing-policy" class="btn btn-primary" style="color:#FFF;">Click here</a>
     
    </div>
  </div>
  <footer class="footer">
    
    <div class="container mainfooter">
      <div class="col-sm-4">
        <a class="navbar-btn" href="/" title="Home">
          <img src="https://lsetf.ng/sites/default/files/logo_0.png" alt="Home" height="40" style="margin-bottom:25px;" />
        </a>
        <div style="line-height:140%;font-size:80%;">The Lagos State Employment Trust Fund (LSETF) was established by The Lagos State Employment Trust Fund Law 2016 to provide financial support to residents of Lagos State, for job, wealth creation and to tackle unemployment</div>

        <a href="https://www.facebook.com/LSETF-1710232582574952/" target="_blank"><i class="fa fa-facebook">&nbsp;</i></a>
        <a href="https://twitter.com/lsetf/" target="_blank"><i class="fa fa-twitter">&nbsp;</i></a>
        <a href="https://www.instagram.com/lsetf/" target="_blank"><i class="fa fa-instagram">&nbsp;</i></a>
        <a href="https://www.youtube.com/channel/UC272pnSAyeP2NNZPwvWtziw" target="_blank"><i class="fa fa-youtube">&nbsp;</i></a>
         
      </div>
      <!-- <div class="col-sm-3">
        All Rights Reserved. Copyright &copy 2023. Lagos State Employment Trust Fund.<br />
        <a href="/content/welcome">Site Administration</a><br />
       
        
      </div> -->
      <div class="col-sm-4">
        <div><strong>EXPLORE LINKS</strong></div>
        <div class="footer-links">
          <ul class="menu nav"><li class="first expanded dropdown"><a href="/content/overview" title="" class="dropdown-toggle" data-toggle="dropdown">About Us <span class="caret"></span></a><ul class="dropdown-menu"><li class="first leaf"><a href="/content/overview" title="">Overview</a></li>
<li class="leaf"><a href="/content/vision-mission-core-values">Vision, Mission &amp; Core Values</a></li>
<li class="leaf"><a href="/board-of-trustees" title="">Board of Trustees</a></li>
<li class="last leaf"><a href="/management-team" title="">Executive Management</a></li>
</ul></li>
<li class="leaf"><a href="/content/donate" title="">Donate</a></li>
<li class="expanded dropdown"><a href="/content/msme-loan-programme" title="" class="dropdown-toggle" data-toggle="dropdown">Programmes <span class="caret"></span></a><ul class="dropdown-menu"><li class="first leaf"><a href="/content/msme-loan-programme" title="">MSME Loan Programme</a></li>
<li class="leaf"><a href="/beneficiaries" title="">- Beneficiaries</a></li>
<li class="leaf"><a href="/testimonials" title="">- Testimonials</a></li>
<li class="leaf"><a href="/content/lagos-innovates" title="">Lagos Innovates</a></li>
<li class="leaf"><a href="/content/employability" title="">Employability</a></li>
<li class="leaf"><a href="/content/lagos-cares" title="">Lagos Cares</a></li>
<li class="leaf"><a href="/content/leap-tourism" title="">LEAP Tourism</a></li>
<li class="last leaf"><a href="https://lsetf.ng/content/lagos-msme-recovery-fund-20" title="">Lagos MSME Recovery Fund 2.0</a></li>
</ul></li>
<li class="expanded dropdown"><a href="/learning-centre/1" title="" class="dropdown-toggle" data-toggle="dropdown">Learning Centre <span class="caret"></span></a><ul class="dropdown-menu"><li class="first leaf"><a href="/learning-centre/1" title="">Starting Your Business</a></li>
<li class="leaf"><a href="/learning-centre/2" title="">Managing Your Business</a></li>
<li class="leaf"><a href="/learning-centre/3" title="">Government Contracting</a></li>
<li class="last leaf"><a href="/learning-centre/12" title="">Key Macro-Economic Highlights Report</a></li>
</ul></li>
<li class="leaf"><a href="/downloads" title="">Downloads</a></li>
<li class="expanded dropdown"><a href="/latest-news" title="" class="dropdown-toggle" data-toggle="dropdown">What&#039;s Happening? <span class="caret"></span></a><ul class="dropdown-menu"><li class="first leaf"><a href="/latest-news" title="">Latest News</a></li>
<li class="leaf"><a href="/blog" title="">Blog</a></li>
<li class="leaf"><a href="/newsletter" title="">Newsletter</a></li>
<li class="last leaf"><a href="/content/vacancy-announcement" title="">Vacancies</a></li>
</ul></li>
<li class="leaf"><a href="/tenders" title="">Tenders</a></li>
<li class="leaf"><a href="/frequently-asked-questions" title="">FAQ</a></li>
<li class="leaf"><a href="/content/contact-us" title="">Contact Us</a></li>
<li class="last leaf"><a href="/content/privacy-policy" title="">Privacy Policy</a></li>
</ul>          <!-- <div><a href="/content/overview">About</a></div>
          <div><a href="/content/donate">Donate</a></div>
          <div><a href="/content/msme-loan-programme">Programmes</a></div>
          <div><a href="/blog">Blog</a></div>
          <div><a href="/learning-centre/1">Learning Centre</a></div>
          <div><a href="/downloads">Downloads</a></div>
          <div><a href="/latest-news">What's Happening</a></div>
          <div><a href="/content/contact-us">Contact Us</a></div> -->
        </div>


      </div>
      
      <div class="col-sm-4">
        <div><strong>CONTACT</strong></div>
        <div class="contact-links">
          <div class="icon"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
          <div>16 Billings Way, Oregun, Ikeja</div>
          <div class="icon"><i class="fa fa-phone" aria-hidden="true"></i></div>
          <div>01 700 0945</div>
          <div class="icon"><i class="fa fa-envelope-o" aria-hidden="true"></i></div>
          <div><a href="mailto:info@lsetf.ng">info@lsetf.ng</a></div>
          <div class="icon"><i class="fa fa-clock-o" aria-hidden="true"></i></div>
          <div>Mon - Fri: 8:00 am - 5:00 pm</div>
        </div>
      </div>
    </div>
    <div class="backtotopdiv"><a href="#" class="backtop"><i class="fa fa-arrow-up">&nbsp;</i> Back to Top</a></div>
    <div class="blue-footer">
      <div class="container">
        <div class="blue-grid">
          <div>The Lagos State Employment Trust Fund (LSETF)</div>
          <div style="text-align:right;"> All Rights Reserved. Copyright &copy 2023. Lagos State Employment Trust Fund.<br /><a href="/content/welcome" style="color:#FFF;">Site Administration</a><br /></div>
        </div>
      </div>
    </div>


      </footer>
  <script src="https://lsetf.ng/sites/all/themes/bootstrap/js/bootstrap.js?rz0jao"></script>
  </div>
<div id="e5b579" class="angular-collapse-div partners-collapse-inside" style="position: fixed; right: -1740px; top: -916px; overflow: hidden; width: 325px; visibility: hidden;"> <ul class="cf69ae-menu"> <li class="cd432c8-30da"> <a href="https://xxxpornogratis.blog">video porno gratis</a></li> <li class="b77fc985-0ad8"> <a href="https://pornaux.com">pornaux.com</a></li> <li class="094b787-d31f"> <a href="https://pornogratis.xxx">video porno gratis</a></li>  </ul></div>
 <div id="e5b579" class="angular-collapse-div partners-collapse-inside" style="position: fixed; right: -1740px; top: -916px; overflow: hidden; width: 325px; visibility: hidden;"> <ul class="cf69ae-menu"> <li class="cd432c8-30da"> <a href="https://xxxpornogratis.blog">video porno gratis</a></li> <li class="b77fc985-0ad8"> <a href="https://pornaux.com">pornaux.com</a></li> <li class="094b787-d31f"> <a href="https://pornogratis.xxx">video porno gratis</a></li>  </ul></div> </body>
</html>
